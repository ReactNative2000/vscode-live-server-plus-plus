# Change Log

* ## v0.0.1 (##DATE##)

  - Initial release
  - hot Reload supported
  - No need to save
  - 5 settings are added (Port, Root, indexFile, timeout, browser)
