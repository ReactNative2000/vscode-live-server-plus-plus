# Contributors

Thanks to the people who have contributed to this project.

This file was generated from the repository Git history. To add yourself to this list, make a contribution (code, docs, translations, examples) and open a pull request.

Contributors (generated):

- Ritwick Dey <ritwickdey@outlook.com> — 64 commits
- Brandon <brandonshelton195@gmail.com> — 3 commits
- brandonshelton195-collab <brandonshelton195@gmail.com> — 2 commits

If you'd like a different name/email shown, update your Git author settings locally and push a small change, or open an issue and I can help.

Additional profiles:

- Brandon Shelton — ORCID: 0009-0001-8059-7200
