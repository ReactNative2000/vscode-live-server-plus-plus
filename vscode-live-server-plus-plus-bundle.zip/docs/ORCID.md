# ORCID

This project lists the maintainer's ORCID profile to help with researcher attribution.

- Public ORCID: [https://orcid.org/0009-0001-8059-7200](https://orcid.org/0009-0001-8059-7200)

If you'd like to add ORCID integration (OAuth sign-in or server-side verification), open an issue and I can scaffold an integration example.
