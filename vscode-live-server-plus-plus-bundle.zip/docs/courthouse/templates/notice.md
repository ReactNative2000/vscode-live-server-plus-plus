# Notice of Hearing

Date: {{ date }}

To: {{ recipient_name }}

Location: {{ courthouse_address }}

Contact Phone: {{ contact_phone }}

Dear {{ recipient_name }},

You are hereby notified of a hearing scheduled at the date and time listed above. Please consult with legal counsel if required.

Instructions:

- Bring government-issued identification.
- Observe courthouse rules and security procedures.

Sincerely,

{{ clerk_name }}
% Notice of Hearing

Date: {{ date }}

To: {{ recipient_name }}

Location: {{ courthouse_address }}

Contact Phone: {{ contact_phone }}

Dear {{ recipient_name }},

You are hereby notified of a hearing scheduled at the date and time listed above. Please consult with legal counsel if required.

Instructions:

- Bring government-issued identification.
- Observe courthouse rules and security procedures.

Sincerely,

{{ clerk_name }}
