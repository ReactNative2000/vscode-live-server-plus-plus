module.exports = {
  timeout: 30_000,
  use: { headless: true },
  testDir: 'test/playwright'
};
